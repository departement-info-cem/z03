function quatreEtCinq(){
    document.querySelector(".quatre").textContent = "Zombies 🧟‍♂️";
    document.querySelector(".cinq").textContent = "Vampires 🧛‍♂️";
}

function byeLicornes(){
    document.querySelector(".trois").textContent = "";
    alert("Bye 😭");
}

function test(){
    console.log("Test réussi !");
}

function texteDeux(){
    document.querySelector(".deux").textContent += " et génies 🧞";
}

function dragonDansConsole(){
    let texteDragon = document.querySelector(".un").textContent;
    console.log(texteDragon);
}

function alerteLicorneMage(){
    let texteLicorne = document.querySelector(".trois").textContent;
    texteLicorne += " et mages 🧙‍♂️";
    alert(texteLicorne);
}
