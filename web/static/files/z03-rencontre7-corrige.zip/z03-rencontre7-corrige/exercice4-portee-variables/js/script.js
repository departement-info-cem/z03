let gNombre = 3;

function nombreConsole(){
    let nombre = 6;
    console.log(nombre);
}
