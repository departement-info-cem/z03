# Rencontre 7 — Corrigé du laboratoire DOM, fonctions et portée

> Essayez d'abord les exercices. Utilisez ce corrigé pour vérifier votre raisonnement et comprendre une erreur.

Ce corrigé utilise seulement les notions vues aux rencontres 6 et 7 : variables avec `let`, `=`, `+=`, chaînes de caractères, `querySelector`, `textContent`, fonctions simples, `console.log()` et `alert()`.

## Exercice 1 — DOM dans la console

Dossier du laboratoire : `exercice1-dom`

### 1. Lire le texte de `.titre1`

```js
document.querySelector(".titre1").textContent
```

### 2. Remplacer le texte de `.texteMC`

```js
document.querySelector(".texteMC").textContent = "Non, c'est un cochon.";
```

### 3. Remplacer `Bokoblin` par `Goomba`

Le titre Bokoblin possède la classe `.titre2`.

```js
document.querySelector(".titre2").textContent = "Goomba";
```

### 4. Passer par une variable

```js
let titre = document.querySelector(".titre3").textContent;
document.querySelector(".textePeppa").textContent = titre;
```

### 5. Ajouter du texte à la fin

Une réponse possible :

```js
document.querySelector(".textePeppa").textContent += " Yikes.";
```

### 6. Ajouter `Peppa pig` au début

```js
let textePeppa = document.querySelector(".textePeppa").textContent;
document.querySelector(".textePeppa").textContent = "Peppa pig" + textePeppa;
```

Le fichier `exercice1-dom/js/corrige.js` contient ces commandes regroupées.

## Exercice 2 — Fonctions mystère

Dossier du laboratoire : `exercice2-fonctions-mystere`

### Remplacer `Pomme 🍎` par `Poire 🍐`

```js
mystere2();
```

### Afficher `Poire 🍐` dans la console

```js
mystere1();
```

### Ajouter `Raisin 🍇` après `Pêche 🍑`

```js
mystere5();
```

Ici, le but est surtout de lire le code des fonctions avant de les appeler.

## Exercice 3 — Créer vos propres fonctions

Dossier du corrigé : `exercice3-creer-fonctions`

```js
function quatreEtCinq(){
    document.querySelector(".quatre").textContent = "Zombies 🧟‍♂️";
    document.querySelector(".cinq").textContent = "Vampires 🧛‍♂️";
}

function byeLicornes(){
    document.querySelector(".trois").textContent = "";
    alert("Bye 😭");
}

function test(){
    console.log("Test réussi !");
}

function texteDeux(){
    document.querySelector(".deux").textContent += " et génies 🧞";
}

function dragonDansConsole(){
    let texteDragon = document.querySelector(".un").textContent;
    console.log(texteDragon);
}

function alerteLicorneMage(){
    let texteLicorne = document.querySelector(".trois").textContent;
    texteLicorne += " et mages 🧙‍♂️";
    alert(texteLicorne);
}
```

Le fichier `exercice3-creer-fonctions/js/script.js` contient cette solution complète.

## Exercice 4 — Portée des variables

Dossier du corrigé : `exercice4-portee-variables`

```js
let gNombre = 3;

function nombreConsole(){
    let nombre = 6;
    console.log(nombre);
}
```

Dans la console :

```js
gNombre
// 3

gNombre += 1;
gNombre
// 4

nombreConsole();
// 6
```

La variable `gNombre` est globale puisqu'elle est déclarée à l'extérieur d'une fonction. La variable `nombre` est locale puisqu'elle est déclarée dans `nombreConsole()`.
