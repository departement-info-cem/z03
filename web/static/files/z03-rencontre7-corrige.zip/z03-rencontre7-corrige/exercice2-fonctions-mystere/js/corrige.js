// Remplacer Pomme 🍎 par Poire 🍐.
mystere2();

// Afficher Poire 🍐 dans la console.
mystere1();

// Ajouter Raisin 🍇 après Pêche 🍑.
mystere5();
