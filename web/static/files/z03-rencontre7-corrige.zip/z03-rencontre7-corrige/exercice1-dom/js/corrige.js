// 1. Lire le texte du premier titre.
document.querySelector(".titre1").textContent;

// 2. Remplacer le texte du paragraphe Minecraft.
document.querySelector(".texteMC").textContent = "Non, c'est un cochon.";

// 3. Remplacer Bokoblin par Goomba.
document.querySelector(".titre2").textContent = "Goomba";

// 4. Lire le texte du troisième titre, puis le réutiliser.
let titre = document.querySelector(".titre3").textContent;
document.querySelector(".textePeppa").textContent = titre;

// 5. Ajouter du texte à la fin.
document.querySelector(".textePeppa").textContent += " Yikes.";

// 6. Ajouter Peppa pig au début du texte existant.
let textePeppa = document.querySelector(".textePeppa").textContent;
document.querySelector(".textePeppa").textContent = "Peppa pig" + textePeppa;
