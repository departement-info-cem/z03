// Corrigé — R9. Consignes originales conservées ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : variables globales
let gCelcius = 20;
let gCouleur = "bleu";
let gAimeCoder = false;
let gBesoinDiplome = false;

// Code fourni — Ne pas modifier : les écouteurs d'événements sont déjà complétés !
function init(){

    document.querySelector(".bouton1").addEventListener("click", reduireCelcius);
    document.querySelector(".bouton2").addEventListener("click", monterCelcius);
    document.querySelector(".bouton3").addEventListener("click", switchCouleur);
    document.querySelector(".bouton4").addEventListener("click", switchAimeCoder);
    document.querySelector(".bouton5").addEventListener("click", switchBesoinDiplome);

    document.querySelector(".bouton6").addEventListener("click", messageTemperature);
    document.querySelector(".bouton7").addEventListener("click", messageLabo);
    document.querySelector(".bouton8").addEventListener("click", messageCouleur);
    document.querySelector(".bouton9").addEventListener("click", messageCouleurMieux);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Compléter messageLabo()
//
// - Si gAimeCoder est true, on remplace le contenu textuel de .texte par 
//   "Faire ce labo m'amuse ! 🥳".
// - Sinon, si gBesoinDiplome est true, le texte sera 
//   "Il faut que je fasse ce labo 🤓".
// - Sinon, le texte sera "Byeeee *mic drop* 🎤".
// Si les deux booléens valent true, gAimeCoder a priorité : seul son message apparaît.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageLabo(){
    // L'ordre des branches donne la priorité au plaisir de coder.
    if (gAimeCoder == true) {
        document.querySelector(".texte").textContent = "Faire ce labo m'amuse ! 🥳";
    } else if (gBesoinDiplome == true) {
        document.querySelector(".texte").textContent = "Il faut que je fasse ce labo 🤓";
    } else {
        document.querySelector(".texte").textContent = "Byeeee *mic drop* 🎤";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 2 : Compléter messageTemperature()
//
// - Si gCelcius vaut 30 ou plus, on remplace le texte de .texte par
//   "J'ai chaud 🥵".
// - Sinon, si gCelcius vaut 10 ou moins, le texte sera "J'ai froid 🥶".
// - Entre 10 et 30 exclusivement, le texte actuel reste inchangé (pas de else).
// Testez notamment 10, 11, 29 et 30. Conservez le nom gCelcius.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageTemperature(){
    if (gCelcius >= 30) {
        document.querySelector(".texte").textContent = "J'ai chaud 🥵";
    } else if (gCelcius <= 10) {
        document.querySelector(".texte").textContent = "J'ai froid 🥶";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 3 : Compléter messageCouleur()
//
// - Si gCouleur vaut "bleu", le texte de .texte deviendra 
//   "Ma couleur préférée : bleu".
// - Sinon, si gCouleur vaut "rouge", le texte sera "Ma couleur préférée : rouge".
// - Sinon, si gCouleur vaut "jaune", le texte sera "Ma couleur préférée : jaune".
// - Sinon, si gCouleur vaut "vert", le texte sera "Ma couleur préférée : vert".
// - Sinon, le texte sera "Ma couleur préférée : rose".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageCouleur(){
    if (gCouleur == "bleu") {
        document.querySelector(".texte").textContent = "Ma couleur préférée : bleu";
    } else if (gCouleur == "rouge") {
        document.querySelector(".texte").textContent = "Ma couleur préférée : rouge";
    } else if (gCouleur == "jaune") {
        document.querySelector(".texte").textContent = "Ma couleur préférée : jaune";
    } else if (gCouleur == "vert") {
        document.querySelector(".texte").textContent = "Ma couleur préférée : vert";
    } else {
        document.querySelector(".texte").textContent = "Ma couleur préférée : rose";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 4 : Compléter messageCouleurMieux()
//
// - Cette fonction fait exactement la même chose que la fonction précédente,
//   mais en mieux : remplacez le tas de if, else if, else ... par une seule
//   ligne de code qui utilise un template string et la variable gCouleur pour
//   afficher le bon message pour les cinq couleurs (bleu, rouge, jaune, vert, rose).
//   Une seule instruction, sans if, else if, else ni autre condition.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageCouleurMieux(){
    document.querySelector(".texte").textContent = `Ma couleur préférée : ${gCouleur}`;
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Code fourni — Ne pas modifier.
// Ne pas toucher le code à partir d'ici. Ce sont seulement les fonctions qui
// permettent de modifier les valeurs des variables globales en jouant avec
// les boutons dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function switchBesoinDiplome(){

    gBesoinDiplome = !gBesoinDiplome
    document.querySelector(".besoinDiplome").textContent = gBesoinDiplome;
    document.querySelector(".texte").textContent = "⌛";

}

function switchAimeCoder(){

    gAimeCoder = !gAimeCoder
    document.querySelector(".aimeCoder").textContent = gAimeCoder;
    document.querySelector(".texte").textContent = "⌛";

}

function switchCouleur(){

    gCouleur = gCouleur == "bleu" ? "rouge" :
        (gCouleur == "rouge" ? "jaune" :
        (gCouleur == "jaune" ? "vert" :
        (gCouleur == "vert" ? "rose" : "bleu")));
    document.querySelector(".couleur").textContent = gCouleur;
    document.querySelector(".texte").textContent = "⌛";

}

function reduireCelcius(){

    gCelcius -= 1;
    document.querySelector(".celcius").textContent = gCelcius;
    document.querySelector(".texte").textContent = "⌛";

}

function monterCelcius(){

    gCelcius += 1;
    document.querySelector(".celcius").textContent = gCelcius;
    document.querySelector(".texte").textContent = "⌛";

}
// Les opérateurs ! (inversion), ? : (ternaires) et +=/-= présents dans le code fourni servent uniquement aux boutons de test; leur fonctionnement n’est pas à apprendre pour cet exercice.
