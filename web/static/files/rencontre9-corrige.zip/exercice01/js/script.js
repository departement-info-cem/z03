// Corrigé — R9. Consignes originales conservées ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : variables globales
let gJeSuisFatigue = false;
let gPrixPantalons = 50;
let gAliment = "brocoli";

// Code fourni — Ne pas modifier : les écouteurs d'événements sont déjà complétés !
function init(){

    document.querySelector(".bouton1").addEventListener("click", switchFatigue);
    document.querySelector(".bouton2").addEventListener("click", switchAliment);
    document.querySelector(".bouton3").addEventListener("click", reduirePrix);
    document.querySelector(".bouton4").addEventListener("click", augmenterPrix);

    document.querySelector(".bouton5").addEventListener("click", messageFatigue);
    document.querySelector(".bouton6").addEventListener("click", messagePrix);
    document.querySelector(".bouton7").addEventListener("click", messageAliment);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Compléter messageFatigue()
//
// - Si gJeSuisFatigue contient true, on remplace le contenu textuel de 
//   l'élément .texte par "Voici la solution : ☕"
//
// Pour tester cette fonction, jouez avec la valeur de gJeSuisFatigue. Quand
// la variable vaut false, il ne devrait rien se passer en cliquant sur le
// bouton Fatigue : le texte actuel doit rester inchangé. Quand la variable vaut true, le message devrait apparaître 
// à la place du sablier ⌛
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageFatigue(){
    // Sans else : false conserve le texte actuel.
    if (gJeSuisFatigue == true) {
        document.querySelector(".texte").textContent = "Voici la solution : ☕";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 2 : Compléter messagePrix()
//
// - Si gPrixPantalons est plus grand ou égal à 100, le texte de .texte
//   est remplacé par "Je vais chercher un rip-off cheap sur Amazon à la place 😏"
// - De plus, si gPrixPantalons est inférieur à 30, le texte de .texte est
//   remplacé par "Wow c'est un beau prix. C'est sus ඞ".
//
// Entre 30 et 99 inclusivement, ne changez pas le texte.
// Lorsque vous testerez, jouez avec la valeur de gPrixPantalons. À 100 et
// plus, vous aurez le message qui mentionne Amazon. À moins de 30 (donc 20
// ou moins vu que la variable fait des bonds de 10) vous aurez le message 
// qui mentionne que c'est sus.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messagePrix(){
    if (gPrixPantalons >= 100) {
        document.querySelector(".texte").textContent = "Je vais chercher un rip-off cheap sur Amazon à la place 😏";
    }
    if (gPrixPantalons < 30) {
        document.querySelector(".texte").textContent = "Wow c'est un beau prix. C'est sus ඞ";
    }
    // Entre les deux seuils, aucune affectation : le texte reste inchangé.
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 3 : Compléter messageAliment()
//
// - Si gAliment vaut "brocoli", on remplace le texte de .texte par 
//   "Miam. Un des aliments avec le plus de nutriments 🥦".
// - Si gAliment ne vaut pas "brocoli", on remplace le texte de .texte par
//   "Huh, c'est mieux le brocoli 🚫🍫".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function messageAliment(){
    if (gAliment == "brocoli") {
        document.querySelector(".texte").textContent = "Miam. Un des aliments avec le plus de nutriments 🥦";
    }
    if (gAliment != "brocoli") {
        document.querySelector(".texte").textContent = "Huh, c'est mieux le brocoli 🚫🍫";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Code fourni — Ne pas modifier.
// Ne pas toucher le code à partir d'ici. Ce sont seulement les fonctions qui
// permettent de modifier les valeurs des variables globales en jouant avec
// les boutons dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function switchFatigue(){

    gJeSuisFatigue = !gJeSuisFatigue;
    document.querySelector(".jeSuisFatigue").textContent = gJeSuisFatigue;
    document.querySelector(".texte").textContent = "⌛";

}

function switchAliment(){

    gAliment = gAliment == "brocoli" ? "chocolat" : "brocoli";
    document.querySelector(".aliment").textContent = gAliment;
    document.querySelector(".texte").textContent = "⌛";

}

function reduirePrix(){

    gPrixPantalons -= 10;
    document.querySelector(".prix").textContent = gPrixPantalons;
    document.querySelector(".texte").textContent = "⌛";

}

function augmenterPrix(){

    gPrixPantalons += 10;
    document.querySelector(".prix").textContent = gPrixPantalons;
    document.querySelector(".texte").textContent = "⌛";

}
// Les opérateurs ! (inversion du booléen), ? : (ternaire) et +=/-= présents dans le code fourni servent uniquement aux boutons de test; leur fonctionnement n’est pas à apprendre pour cet exercice.
