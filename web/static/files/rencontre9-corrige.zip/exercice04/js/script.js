// Corrigé enseignant privé — R9. Consignes originales conservées ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : les écouteurs sont déjà en place.
function init(){
    document.querySelector(".bouton8").addEventListener("click", alternerImage);
}

// Consigne originale 1 : Avec if/else, vérifiez la valeur de l'attribut alt de
// .objetBrun. Si elle vaut "Poop", donnez à src la valeur
// "images/chocolate.png" et à alt la valeur "Chocolat".
// Sinon, redonnez "images/poop.png" à src et "Poop" à alt.
// Le bouton est déjà câblé. Au premier clic : Chocolat; au deuxième : Poop.
// À chaque clic, modifiez src ET alt pour garder les deux états cohérents.
function alternerImage(){
    let image = document.querySelector(".objetBrun");
    // L'attribut alt indique l'état actuel; src et alt changent ensemble.
    if (image.getAttribute("alt") === "Poop") {
        image.setAttribute("src", "images/chocolate.png");
        image.setAttribute("alt", "Chocolat");
    } else {
        image.setAttribute("src", "images/poop.png");
        image.setAttribute("alt", "Poop");
    }
}
