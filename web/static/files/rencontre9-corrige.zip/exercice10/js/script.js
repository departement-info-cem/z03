// Corrigé — R9. Consignes originales conservées ci-dessous.
// Le HTML, le CSS et les déclarations des variables sont fournis.
// Conservez ces déclarations; votre code doit réaffecter leurs valeurs.
// Créez les écouteurs dans init() et les fonctions nécessaires, sans modèle imposé.
// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Tout coder
//
// Il y a trois boutons à rendre fonctionnels :
//
// 1 - .papier : ajouter une feuille à gNbFeuilles et actualiser .feuilles.
// 2 - .encre : remettre gPourcentageEncre à 100 et actualiser .cartouches
//   avec le symbole % (100 %).
//
// (Pour ces deux premiers boutons, n'oubliez pas de mettre à jour l'affichage
// dans la page Web. N'oubliez pas le symbole % pour l'encre)
//
// ⏳ Une fois que les deux premiers boutons fonctionnent, passez au troisième :
// 
// 3 - .impression : un bouton pour imprimer. C'est le plus complexe, voici le comportement
//     de l'imprimante selon la situation :
//
// Vérifiez le papier EN PREMIER, puis l’encre seulement si le papier suffit.
// Si les deux manquent, seul le message papier apparaît et une seule alerte
// est déclenchée. Un refus ne consomme ni feuille ni encre.
//
// → Il reste 0 feuille : 
//      • Pas d'impression  
//      • Message dans la console "Veuillez ajouter du papier !! Et avec le bon format SVP ! 😠📃"
//
// → Il reste MOINS de 20 % d'encre :
//      • Pas d'impression
//      • Message dans la console "Veuillez changer les cartouches !! Elles sont VIDES ! 😠🎨"
//
// → Au moins une feuille et au moins 40 % d'encre :
//      • On imprime !
//
// → Au moins une feuille et au moins 20 % (mais moins de 40 %) d'encre :
//      • On imprime !
//      • Message dans la console : "Attention les cartouches sont faibles !! 😠🎨"
//
// ❌ Dans tous les cas, si l'impression n'a pas fonctionné :
//     • On crée l'alerte "Impression ANNULÉE 🚔🤬"
//
// ✅ Dans tous les cas, si l'impression fonctionne :
//     • On affiche dans la console "Page imprimée !"
//     • On diminue gPourcentageEncre de 5 points de pourcentage
//       et on met à jour .cartouches avec le symbole %.
//     • On diminue gNbFeuilles de 1 et on met à jour .feuilles.
//
// À 20 % exactement, on imprime AVEC avertissement. À 40 % exactement,
// on imprime SANS avertissement. Consultez le tableau de tests dans la page.
// Une impression réussie affiche toujours "Page imprimée !" dans la console.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Code fourni : déclarations et valeurs de départ à conserver après les tests.
let gNbFeuilles = 5;
let gPourcentageEncre = 80;

function init(){
    document.querySelector(".papier").addEventListener("click", ajouterPapier);
    document.querySelector(".encre").addEventListener("click", changerCartouches);
    document.querySelector(".impression").addEventListener("click", imprimer);
    actualiserAffichage();
}

function ajouterPapier(){
    gNbFeuilles += 1;
    actualiserAffichage();
}

function changerCartouches(){
    gPourcentageEncre = 100;
    actualiserAffichage();
}

function actualiserAffichage(){
    document.querySelector(".feuilles").textContent = gNbFeuilles;
    document.querySelector(".cartouches").textContent = gPourcentageEncre + " %";
}

function imprimer(){
    // Les branches exclusives garantissent un seul refus, papier prioritaire.
    if (gNbFeuilles == 0) {
        console.log("Veuillez ajouter du papier !! Et avec le bon format SVP ! 😠📃");
        alert("Impression ANNULÉE 🚔🤬");
    } else if (gPourcentageEncre < 20) {
        console.log("Veuillez changer les cartouches !! Elles sont VIDES ! 😠🎨");
        alert("Impression ANNULÉE 🚔🤬");
    } else {
        // Le seuil porte sur l'encre disponible AVANT l'impression.
        if (gPourcentageEncre < 40) {
            console.log("Attention les cartouches sont faibles !! 😠🎨");
        }
        console.log("Page imprimée !");
        gNbFeuilles -= 1;
        gPourcentageEncre -= 5;
        actualiserAffichage();
    }
}
