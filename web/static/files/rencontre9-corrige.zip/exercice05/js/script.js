// Corrigé — R9. Consignes originales conservées ci-dessous.
// Le HTML et le CSS sont fournis; le comportement JavaScript est à créer.
// Code fourni : conservez la déclaration; réaffectez sa valeur dans votre fonction.
let gCouleur = "bleu";

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Il faut tout coder ! Lisez les instructions dans la page HTML.
// - Notez qu'il y a deux images d'ampoules dans la page : une bleue et une 
//   rouge.
// - Utilisez gCouleur : "bleu" au départ, puis "rouge" ou "bleu" selon l’image visible.
// - Dans init(), ajoutez un écouteur de clic sur .bouton vers une nouvelle fonction.
// - Dans cette fonction, utilisez if/else pour modifier style.display de
//   .lightBlue et .lightRed : "block" affiche, "none" cache.
// - Réaffectez gCouleur à chaque changement. Une seule image doit être visible.
// - Testez : premier clic rouge, deuxième clic bleu, puis répétez.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){
    document.querySelector(".bouton").addEventListener("click", changerAmpoule);
}

// N'hésitez pas à créer une nouvelle fonction ici

function changerAmpoule(){
    if (gCouleur == "bleu") {
        document.querySelector(".lightBlue").style.display = "none";
        document.querySelector(".lightRed").style.display = "block";
        gCouleur = "rouge";
    } else {
        document.querySelector(".lightBlue").style.display = "block";
        document.querySelector(".lightRed").style.display = "none";
        gCouleur = "bleu";
    }
}
