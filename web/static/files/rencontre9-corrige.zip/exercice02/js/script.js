// Corrigé — R9. Consignes originales conservées ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : variables globales
let gAge = 15;
let gNom = "Yolande";
let gStyle = "Flashy";

// Code fourni — Ne pas modifier : les écouteurs d'événements sont déjà complétés !
function init(){

    document.querySelector(".bouton1").addEventListener("click", reduireAge);
    document.querySelector(".bouton2").addEventListener("click", augmenterAge);
    document.querySelector(".bouton3").addEventListener("click", changerNom);
    document.querySelector(".bouton4").addEventListener("click", changerStyle);

    document.querySelector(".bouton6").addEventListener("click", sinon1);
    document.querySelector(".bouton7").addEventListener("click", sinon2);
    document.querySelector(".bouton8").addEventListener("click", sinon3);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Compléter sinon1() — bouton « Yolande ou Ali »
//
// - Si gNom est exactement égal à "Yolande", le texte de .texte devient "Yo Yolande ! 👋". 
//   Sinon, le texte devient "Allo Ali ! 👋".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function sinon1(){
    if (gNom == "Yolande") {
        document.querySelector(".texte").textContent = "Yo Yolande ! 👋";
    } else {
        document.querySelector(".texte").textContent = "Allo Ali ! 👋";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 2 : Compléter sinon2() — bouton « Manège »
//
// - Si gAge est inférieur à 13, le texte de .texte sera 
//   "Pas de tour de manège pour toi ! 😭". 
//   Sinon, le texte sera "Bon tour de manège ! 🎢".
// Testez 12 ans (refus) et 13 ans (acceptation) avec les flèches, puis Manège.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function sinon2(){
    if (gAge < 13) {
        document.querySelector(".texte").textContent = "Pas de tour de manège pour toi ! 😭";
    } else {
        document.querySelector(".texte").textContent = "Bon tour de manège ! 🎢";
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 3 : Compléter la fonction sinon3() — bouton « Style »
//
// - Si gStyle vaut "Flashy", on veut les styles suivants pour .texte : 
//   bordure de couleur "magenta", couleur de fond "cyan" et texte de couleur
//   "crimson".
//   (Utilisez style.borderColor, style.color et style.backgroundColor)
// - Sinon, on veut les styles suivants : bordure de couleur "black", couleur 
//   de fond "white" et texte de couleur "black".
//
// - De plus, dans tous les cas, APRÈS le if else, le texte de la boîte est 
//   changé pour "Le style X a été appliqué.", où X doit être remplacé par la 
//   valeur de la variable gStyle à l'aide d'une concaténation. (Ce qui
//   donnera quelque chose comme "Le style Flashy a été appliqué.")
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function sinon3(){
    let texte = document.querySelector(".texte");
    if (gStyle == "Flashy") {
        texte.style.borderColor = "magenta";
        texte.style.backgroundColor = "cyan";
        texte.style.color = "crimson";
    } else {
        texte.style.borderColor = "black";
        texte.style.backgroundColor = "white";
        texte.style.color = "black";
    }
    // Cette phrase est commune aux deux branches.
    texte.textContent = "Le style " + gStyle + " a été appliqué.";
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Code fourni — Ne pas modifier.
// Ne pas toucher le code à partir d'ici. Ce sont seulement les fonctions qui
// permettent de modifier les valeurs des variables globales en jouant avec
// les boutons dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function reduireAge(){
    gAge -= 1;
    document.querySelector(".age").textContent = gAge;
    document.querySelector(".texte").textContent = "⌛";
}

function augmenterAge(){
    gAge += 1;
    document.querySelector(".age").textContent = gAge;
    document.querySelector(".texte").textContent = "⌛";
}

function changerNom(){
    gNom = gNom == "Yolande" ? "Ali" : "Yolande";
    document.querySelector(".nom").textContent = gNom;
    document.querySelector(".texte").textContent = "⌛";
}

function changerStyle(){
    gStyle = gStyle == "Flashy" ? "Sobre" : "Flashy";
    document.querySelector(".style").textContent = gStyle;
    document.querySelector(".texte").textContent = "⌛";
}
// Les opérateurs ? : (ternaire) et +=/-= présents dans le code fourni servent uniquement aux boutons de test; leur fonctionnement n’est pas à apprendre pour cet exercice.
