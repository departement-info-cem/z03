// Corrigé — R9. Consignes originales conservées ci-dessous.
// Corrigez init() et les cinq fonctions texteBleu, texteRouge, texteVert,
// texteVariable et bordureOuFond. Conservez les variables globales et les
// fonctions fournies changerCouleur() et changerStyle().
// Code fourni — Ne pas modifier : variables globales
let gCouleur = "pink";
let gStyle = "bordure";

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Consigne originale 1 : Bogues simples 😇
// - Les cinq boutons dans la page fonctionnent mal. Testez-les, identifiez
//   ce qui fonctionne mal et corrigez les bogues dans le périmètre indiqué.
// - Ouvrez la console, actualisez, puis testez. Corrigez une erreur à la fois,
//   sauvegardez, actualisez et retestez. Vérifiez aussi le résultat visuel.
//
// Résultat attendu : les cinq boutons modifient .texte, selon leur libellé.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){
    // querySelector est sensible aux majuscules.
    document.querySelector(".bleu").addEventListener("click", texteBleu);
    document.querySelector(".rouge").addEventListener("click", texteRouge);
    document.querySelector(".vert").addEventListener("click", texteVert);
    document.querySelector(".variable").addEventListener("click", texteVariable);
    document.querySelector(".styleBoite").addEventListener("click", bordureOuFond);
    document.querySelector(".bouton1").addEventListener("click", changerCouleur);
    document.querySelector(".bouton2").addEventListener("click", changerStyle);
}

// Cette fonction rend le texte dans la boîte bleu.
function texteBleu(){
    document.querySelector(".texte").style.color = "blue";
}

// Cette fonction rend le texte dans la boîte rouge.
function texteRouge(){
    // Le point vise une classe et la couleur passe par style.
    document.querySelector(".texte").style.color = "red";
}

// Cette fonction rend le texte dans la boîte vert.
function texteVert(){
    // On colore la boîte de texte, pas le bouton vert.
    document.querySelector(".texte").style.color = "green";
}

// Cette fonction rend le texte dans la boîte rose ou jaune (selon la valeur de gCouleur)
function texteVariable(){
    // Sans guillemets : on lit la valeur de la variable.
    document.querySelector(".texte").style.color = gCouleur;
}

// Cette fonction change la couleur de fond ou la couleur de la bordure selon la valeur
// de gStyle ("bordure" ou "fond"). Utilisez gCouleur ("pink" ou "gold").
// Ne modifiez que la propriété choisie; conservez l’autre propriété.
function bordureOuFond(){
    // Le choix dépend du style; une seule propriété change.
    if (gStyle == "bordure") {
        document.querySelector(".texte").style.borderColor = gCouleur;
    } else {
        document.querySelector(".texte").style.backgroundColor = gCouleur;
    }
}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Code fourni — Ne pas modifier.
// Ne pas toucher le code à partir d'ici. Ce sont seulement les fonctions qui
// permettent de modifier les valeurs des variables globales en jouant avec
// les boutons dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function changerCouleur(){
    gCouleur = gCouleur == "pink" ? "gold" : "pink";
    document.querySelector(".couleur").textContent = gCouleur;
}

function changerStyle(){
    gStyle = gStyle == "bordure" ? "fond" : "bordure";
    document.querySelector(".style").textContent = gStyle;
}
// L’opérateur ? : (ternaire) présent dans le code fourni sert uniquement aux boutons de test; son fonctionnement n’est pas à apprendre pour cet exercice.
