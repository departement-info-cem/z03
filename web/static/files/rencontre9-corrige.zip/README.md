# Corrigés — Rencontre 9

Essayez d'abord les exercices avant de consulter les solutions.

Extrayez toute cette archive dans un dossier distinct de vos exercices pour conserver votre travail. Ouvrez ensuite le fichier `index.html` du dossier `exercice01` à `exercice10` dans un navigateur. Aucune installation ni connexion n'est nécessaire.

Les solutions sont déjà complétées dans `js/script.js`. Utilisez les boutons pour essayer leur fonctionnement, puis comparez le code avec votre solution pour comprendre les différences.
