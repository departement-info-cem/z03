# Corrigés enseignants privés — Rencontre 9

Dix solutions complètes, réservées à l'enseignant. Extraire toute l'archive, puis ouvrir `exercice01/index.html` à `exercice10/index.html` dans un navigateur. Aucune installation ni connexion nécessaire.

Les boutons de chaque page sont fonctionnels. Le HTML, le CSS, les images et le README étudiant sont conservés à l'identique. Les consignes étudiantes restent donc affichées, même si le JavaScript est déjà complété. Les commentaires « Consigne originale » décrivent les tâches maintenant résolues. Les scripts comportent quelques commentaires pédagogiques courts.

Source exclusive : `web/static/files/rencontre9.zip` du commit `38217b5a0c54144de6460e0fb45bb4f6f7728759`. Les solutions sont autonomes : aucun fichier du site n'est nécessaire après extraction.

- Ex01 : conditions simples; absence de changement quand la condition est fausse.
- Ex02 : alternatives `if/else`, âge 12/13, couleurs et message commun après la condition.
- Ex03 : `classList.contains("brun")`; ajouter/retirer la classe dans l'inspecteur pour tester.
- Ex04 : alternance synchronisée de `src` et `alt`.
- Ex05 : alternance des ampoules; une seule image visible et variable cohérente.
- Ex06 : deux décisions indépendantes pour Ice Bro et Fire Bro; seuils 10 et 15 °C.
- Ex07 : `else if`, priorité à `gAimeCoder`, seuils 10/30, cinq couleurs et version en une seule instruction avec littéral de gabarit.
- Ex08 : OU, ET, égalité des prix; budget égal au coût accepté; pommes prioritaires; simulation sans consommation d'argent.
- Ex09 : tous les bogues corrigés dans le script enseignant; variables et fonctions de réglage préservées.
- Ex10 : papier vérifié avant l'encre; un refus ne consomme rien; une seule alerte; seuils avant impression 20 %/40 %; consommation 1 feuille/5 points; messages exacts.

Le rapport de validation et le manifeste des fichiers sont inclus. Le ZIP étudiant n'a pas été modifié. Aucun contenu de ce corrigé n'a été ajouté au site, à GitHub ou à Pages.
