# Rapport de validation — Corrigés enseignants R9

Date : 2026-10-16. Livrable strictement local privé; aucun commit, push, déploiement ou changement de fichier suivi.

## Emplacement et source

Archive : `P:\Projects\_CEGEP\Z03-EMCMP\.codex-temp\corriges-r9\rencontre9-corrige-enseignant.zip`

Version étudiante de référence : `web/static/files/rencontre9.zip` au commit `38217b5a0c54144de6460e0fb45bb4f6f7728759`. SHA-256 : `3275f9fbf2dd16eab132611f3fd32b30f986f0b8d4d1f0b10fe07fa9456ffbf2`.

Écart de contexte constaté : le dépôt principal local est à `cd7ecd52489564bc075099d89f39ab1bc5fb4a29` et contient un ancien ZIP. La version demandée a été retrouvée dans le clone local `.codex-temp/reconciliation-r9` à `38217b5`, puis comparée octet pour octet au blob du commit. Le journal de livraison existant confirme le même SHA-256 pour le ZIP public. Aucun téléchargement de corrigé ni publication n'a eu lieu pendant cette tâche; l'état distant actuel n'a pas été interrogé.

## Conventions et confidentialité

Inspection préalable : AGENTS racine et web, REFONTE, plan et suivi R9, .gitignore, corrigés R6/R7 et workflow Pages. Les corrigés existants de R6 (page Markdown) et R7 (ZIP) sont publics; aucune convention de corrigé enseignant privé dédiée n'a été trouvée. Les dossiers sources/archives suivis sont des archives historiques, pas un espace privé. Le workflow publie `web/build`.

Stockage retenu : `.codex-temp/corriges-r9/`, exclu par `/.codex-temp/` dans `.gitignore`. Vérification Git : `.gitignore:2:/.codex-temp/	"P:\\Projects\\_CEGEP\\Z03-EMCMP\\.codex-temp\\corriges-r9\\rencontre9-corrige-enseignant.zip"`. Aucun fichier de ce dossier n'est suivi. Aucun corrigé n'est placé dans `web/static` ou référencé par une page étudiante.

## Contenu et intégrité

- Dix dossiers autonomes `exercice01` à `exercice10`, chacun avec index.html, css/styles.css, js/script.js et les images d'origine nécessaires.
- Les 47 entrées du ZIP étudiant sont conservées : seuls les dix scripts changent; les 37 autres fichiers sont identiques octet pour octet (10 HTML, 10 CSS, 16 images et README étudiant).
- Ajouts enseignants : LIRE-MOI-ENSEIGNANT.md, RAPPORT-VALIDATION.md et MANIFESTE.json.
- Consignes originales conservées dans le HTML et les commentaires; quelques commentaires pédagogiques discrets ajoutés dans les solutions.
- Ex09 : correction de queryselector → querySelector, du sélecteur rouge et de style.color, de la cible verte, de la chaîne "gCouleur" et du mauvais test dans bordureOuFond. texteBleu était déjà correct et reste équivalent; tout le code fourni à conserver est préservé.
- Ex10 : branches exclusives papier → encre → succès; contrôles sur l'encre avant consommation. À 20 %, avertissement et impression; à 40 %, impression sans avertissement. Une réussite consomme 1 feuille et 5 points; un refus ne consomme rien et déclenche exactement une alerte. Messages copiés exactement des consignes.

## Syntaxe et analyse statique

- Node v20.19.0 : `node --check` réussi sur les 10 scripts.
- Analyse AST Babel : 10/10 scripts analysés; aucun identifiant référencé non déclaré; tous les sélecteurs présents dans le HTML; les 50 écouteurs click visent des fonctions déclarées.
- Comparaison AST des déclarations et fonctions fournies hors périmètre à compléter : identiques. La version Couleur (mieux) contient une seule instruction avec un littéral de gabarit, sans condition.
- 26 références HTML locales résolues; aucune ressource manquante. Images chargées avec dimensions naturelles non nulles dans le navigateur.

## Tests fonctionnels automatisés

Microsoft Edge 155.0.4283.45, Playwright local, ouverture `file://` hors réseau. 2716 assertions réussies sur 2716; aucune exception de page ni requête de ressource échouée. Le journal global des erreurs console est vide. La suite complète a été rejouée sur le contenu extrait du ZIP. Après actualisation du présent rapport, chaque fichier d’exercice du ZIP final a été comparé octet pour octet au fichier testé; seule la documentation de livraison a changé.

Chaque bouton est actionné par un vrai clic Playwright. Les matrices plus volumineuses des exercices 08 et 10 utilisent ensuite element.click() dans le navigateur, passant par les mêmes écouteurs DOM. Les valeurs aux limites sont injectées temporairement dans la page de test; les fichiers livrés conservent leurs valeurs initiales. Les messages attendus sont définis indépendamment dans les tests.

| Exercice | Assertions réussies | Fonctions JS nommées exécutées / présentes (V8) | Couverture fonctionnelle |
|---|---:|---:|---|
| exercice01 | 18 / 18 | 8/8 | Fatigue true/false et conservation du texte; prix 20, 29, 30, 90, 99, 100, 110; deux aliments; tous les boutons de réglage. |
| exercice02 | 14 / 14 | 8/8 | Yolande/Ali et casse exacte; âge 12/13; aller-retour Flashy/Sobre avec trois propriétés CSS et phrase exacte. |
| exercice03 | 6 / 6 | 2/2 | Classe brun absente, ajoutée, retirée; rechargement et nouveau clic. |
| exercice04 | 8 / 8 | 2/2 | État initial puis six clics; src/alt cohérents; images effectivement chargées. |
| exercice05 | 15 / 15 | 2/2 | État initial puis six clics; affichages block/none, une image visible et variable cohérente. |
| exercice06 | 49 / 49 | 4/4 | Température de 20 à 9 puis de 10 à 21 par les flèches; unité et deux opacités à chaque étape, dont 10, 11, 12, 14 et 15. |
| exercice07 | 32 / 32 | 10/10 | Températures 9, 10, 11, 20, 29, 30, 31; texte préservé au milieu; quatre couples de booléens; cycle complet des cinq couleurs et comparaison des deux versions. |
| exercice08 | 1281 / 1281 | 13/13 | Huit boutons de réglage; 64 triplets de prix dans {3,4,5,6} pour OU/ET/égalité; 540 budgets (27 triplets dans {1,3,6}, montant 0 à 19), égalités incluses et absence de consommation. |
| exercice09 | 31 / 31 | 8/8 | Cinq boutons, couleurs de texte blue/red/green/pink/gold, boutons non recolorés; quatre couples pink/gold × bordure/fond et préservation de la propriété non choisie. |
| exercice10 | 1262 / 1262 | 5/5 | Trois boutons; cas publiés 0/80, 1/15, 1/20, 1/35, 1/40, 1/80 et 0/15; cas 1/19, 1/39, 0/0; 303 couples de 0, 1, 5 feuilles × encre entière 0..100; messages, alertes, valeurs et affichages; séquence d’épuisement/recharge; retour à 5/80 au rechargement. |

La mesure V8 porte sur les scripts des exercices, hors HTML et hors harnais. Toutes les fonctions nommées et toutes les plages d’exécution rapportées par V8 ont été exécutées au moins une fois. Cette mesure et les matrices testées ne constituent pas une preuve pour toutes les valeurs possibles.

## Limites et écarts

- Aucun écart fonctionnel détecté par rapport aux consignes de la version 38217b5.
- Tests sur Edge/Chromium Windows uniquement; Firefox, Safari, appareils mobiles et revue humaine exhaustive du rendu non exécutés. Captures des dix pages conservées localement.
- Le texte étudiant affiché reste volontairement celui des pages originales, même lorsqu'il demande de compléter du code déjà résolu dans ce corrigé.
- Les entrées hors des situations proposées (types arbitraires, nombres négatifs saisis dans la console, etc.) ne font pas l'objet d'exigences supplémentaires.
- Build Docusaurus non exécuté : aucun fichier sous web/ n'a été modifié, les livrables sont des pages HTML autonomes privées.

## Contrôle des originaux et de Git

- `P:\Projects\_CEGEP\Z03-EMCMP\web\static\files\rencontre9.zip` : SHA-256 `522308c8f226642a656a0579b24eadc8be72fb86218c489259405949b107edf5`, inchangé.
- `P:\Projects\_CEGEP\Z03-EMCMP\.codex-temp\reconciliation-r9\web\static\files\rencontre9.zip` : SHA-256 `3275f9fbf2dd16eab132611f3fd32b30f986f0b8d4d1f0b10fe07fa9456ffbf2`, inchangé.

Git principal : HEAD inchangé, état suivi et non suivi visible propre; aucun fichier ajouté à l'index; aucun commit/push. Le clone de réconciliation et ses fichiers préexistants n'ont pas été modifiés.

## Preuves et reprise locale

À côté du ZIP : PLAN.md, source-et-integrite.json, source-etudiante/, solutions/, scripts preparer.py et livrer.py; dossier verification/ avec scripts statique.cjs et navigateur.py, résultats JSON, couverture V8, captures PNG et contrôle final de l'archive. Ces outils de vérification restent locaux, hors de l'archive d'utilisation.

Syntaxe/analyse : exécuter Node 20.19.0 disponible dans `.codex-temp/r9-approved-20261016/node20/node.exe` avec `verification/statique.cjs`. Navigateur : exécuter `verification/navigateur.py` avec le Python de l'environnement Playwright déjà présent (`%LOCALAPPDATA%/LocalAI/BrowserUse/Runtime/venv/Scripts/python.exe`); un argument permet de viser une extraction de l'archive. Aucune dépendance du dépôt n'a été modifiée.
