# Rapport de validation — Corrigés R9

## État courant — 2026-10-16

Archive versionnée : `web/static/files/rencontre9-corrige.zip`. Dix solutions exécutables, diffusées séparément des fichiers à compléter. La page `web/docs/02-labos/04-labo5.md` propose les deux ZIP avec un avertissement avant consultation du corrigé. Les ressources placées sous `web/static/` sont incluses dans le build public du site.

Cette mise en cohérence est limitée au dépôt personnel `emcmp/Z03`. La livraison se fait par une branche personnelle et une PR; son workflow construit le site sans déclencher le job de déploiement. La production du cégep n'est pas visée.

Les dix scripts ont été inspectés. Dix-sept comparaisons ont été adaptées à la syntaxe utilisée dans les exercices, après vérification des types et des fonctions de réglage. Les en-têtes des scripts et la documentation reflètent maintenant la diffusion séparée. Aucun autre code exécutable ni consigne étudiante n'a été modifié. Le manifeste est recalculé sur tous les fichiers de l'archive sauf lui-même.

## Provenance et étapes historiques

- Source étudiante : `web/static/files/rencontre9.zip` au commit `38217b5a0c54144de6460e0fb45bb4f6f7728759`, SHA-256 `3275f9fbf2dd16eab132611f3fd32b30f986f0b8d4d1f0b10fe07fa9456ffbf2`.
- Les solutions ont d'abord été préparées et testées localement dans `.codex-temp/corriges-r9/`. À cette étape seulement, elles n'étaient pas diffusées sur le site. Le main local historique était alors à `cd7ecd52489564bc075099d89f39ab1bc5fb4a29`; cette version est conservée par `sauvegarde/rencontre9-cd7ecd5`.
- `b56282b` a intégré temporairement les réponses aux pages du ZIP étudiant; `2f9ccda` a restauré l'archive sans réponses. `12812aa` a ajouté le présent corrigé séparé. Workflow réussi de cette livraison : https://github.com/emcmp/Z03/actions/runs/38940277864.
- Base de la présente mise en cohérence : `e8cb64061985989e4d59abb6075c7cba6420fc58`, main personnel propre et aligné avec origin/main avant création de la branche.

## Contrôles du présent lot

- CRC des deux archives : valides; 47 fichiers étudiants et 50 fichiers corrigés, dix dossiers et dix scripts chacun; 26 références HTML locales résolues par archive.
- ZIP étudiant inchangé, SHA-256 identique à la source de référence; fonctions à compléter vides, erreurs intentionnelles de 09 conservées, aucune réponse intégrée. Les 37 fichiers communs hors JavaScript sont identiques entre les deux archives.
- Node 20.19.0 : 20/20 scripts passent `node --check` (dix étudiants, dix solutions). Analyse AST des dix solutions réussie : code fourni préservé, sélecteurs et écouteurs valides.
- Suite Playwright existante rejouée sur les solutions extraites du ZIP modifié : 2716/2716 assertions réussies dans Microsoft Edge 155.0.4283.45; aucune exception, erreur de console ou ressource manquante. La matrice historique ci-dessous décrit aussi la couverture de cette nouvelle exécution.
- `npm run typecheck` et `npm run build` réussis depuis la racine sous Node 20.19.0. Avertissements hérités de configuration et de données de dépendances; aucune dépendance modifiée.
- Suite existante `scripts/deploiement/tests/run-tests.ps1` : 21/21 tests réussis, dont acceptation de Laboratoires et refus de Refonte dans la navigation publique. Aucun script de déploiement modifié.
- Après cette actualisation documentaire, les scripts, HTML, CSS et images sont comparés octet pour octet aux fichiers testés. Le manifeste SHA-256 est recalculé sur les 49 autres fichiers et les CRC sont revérifiés. Les résultats de CI de la PR sont consignés dans le rapport de livraison personnel et le journal local.

## Validation fonctionnelle de la première préparation — historique

Les premières solutions ont passé 2716 assertions dans Edge/Chromium sous Windows, via Playwright local. Les clics, seuils, messages, ressources et erreurs de console étaient contrôlés. Dix scripts avaient passé `node --check` sous Node 20.19.0 et une analyse AST; les 50 écouteurs visaient des fonctions déclarées, les 26 références HTML locales étaient résolues. Le build Docusaurus n'avait pas été exécuté lors de cette préparation locale initiale.

| Exercice | Assertions réussies | Fonctions JS nommées exécutées / présentes (V8) | Couverture fonctionnelle |
|---|---:|---:|---|
| exercice01 | 18 / 18 | 8/8 | Fatigue true/false et conservation du texte; prix 20, 29, 30, 90, 99, 100, 110; deux aliments; tous les boutons de réglage. |
| exercice02 | 14 / 14 | 8/8 | Yolande/Ali et casse exacte; âge 12/13; aller-retour Flashy/Sobre avec trois propriétés CSS et phrase exacte. |
| exercice03 | 6 / 6 | 2/2 | Classe brun absente, ajoutée, retirée; rechargement et nouveau clic. |
| exercice04 | 8 / 8 | 2/2 | État initial puis six clics; src/alt cohérents; images effectivement chargées. |
| exercice05 | 15 / 15 | 2/2 | État initial puis six clics; affichages block/none, une image visible et variable cohérente. |
| exercice06 | 49 / 49 | 4/4 | Température de 20 à 9 puis de 10 à 21 par les flèches; unité et deux opacités à chaque étape, dont 10, 11, 12, 14 et 15. |
| exercice07 | 32 / 32 | 10/10 | Températures 9, 10, 11, 20, 29, 30, 31; texte préservé au milieu; quatre couples de booléens; cycle complet des cinq couleurs et comparaison des deux versions. |
| exercice08 | 1281 / 1281 | 13/13 | Huit boutons de réglage; 64 triplets de prix dans {3,4,5,6} pour OU/ET/égalité; 540 budgets (27 triplets dans {1,3,6}, montant 0 à 19), égalités incluses et absence de consommation. |
| exercice09 | 31 / 31 | 8/8 | Cinq boutons, couleurs de texte blue/red/green/pink/gold, boutons non recolorés; quatre couples pink/gold × bordure/fond et préservation de la propriété non choisie. |
| exercice10 | 1262 / 1262 | 5/5 | Trois boutons; cas publiés 0/80, 1/15, 1/20, 1/35, 1/40, 1/80 et 0/15; cas 1/19, 1/39, 0/0; 303 couples de 0, 1, 5 feuilles × encre entière 0..100; messages, alertes, valeurs et affichages; séquence d’épuisement/recharge; retour à 5/80 au rechargement. |

La mesure V8 porte sur les scripts des exercices, hors HTML et hors harnais. Toutes les fonctions nommées et toutes les plages d’exécution rapportées par V8 ont été exécutées au moins une fois. Cette mesure et les matrices testées ne constituent pas une preuve pour toutes les valeurs possibles.

## Limites et consignes conservées

Les tests couvrent les données et manipulations proposées dans les exercices; ils n'ajoutent aucune exigence sur des types arbitraires saisis dans la console. Les tests de navigateur portent sur Edge/Chromium Windows; Firefox, Safari et les appareils mobiles ne sont pas couverts.

Les dix HTML, dix CSS, seize images et le README étudiant restent identiques à l'archive étudiante de référence. Les consignes originales restent visibles même lorsqu'elles demandent de compléter du code déjà résolu dans ce corrigé. L'exercice 09 est corrigé ici seulement; les erreurs intentionnelles sont conservées dans le ZIP étudiant. L'imprimante conserve ses messages, priorités et consommations.

Les outils, extractions et preuves du présent lot sont locaux sous `.codex-temp/r9-coherence-20261016/`; ils ne sont pas ajoutés au matériel téléchargeable. Les preuves de la préparation initiale restent sous `.codex-temp/corriges-r9/verification/`.
