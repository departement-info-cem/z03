// Code à compléter : suivez tous les TODO ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : les écouteurs sont déjà en place.
function init(){
    document.querySelector(".bouton4").addEventListener("click", verifierClasse);
}

// TODO 1 : Avec classList.contains() et if/else, vérifiez si .texte1
// possède la classe "brun". Affichez "Je suis brun 🍫" ou
// "Je ne suis pas brun 🚫🍫" dans son textContent.
// Le bouton est déjà câblé dans init(). Testez d’abord sans "brun",
// puis, dans l’inspecteur, changez class="texte1" en class="texte1 brun"
// et cliquez de nouveau. Actualiser annule cette modification temporaire.
function verifierClasse(){

}


