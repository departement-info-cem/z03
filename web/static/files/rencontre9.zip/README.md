# Laboratoire de la rencontre 9 — Conditions et logique

Ouvrez le dossier de chaque exercice, puis son fichier index.html dans un navigateur. Lisez les consignes affichées et complétez les TODO dans js/script.js. Ne modifiez pas le code marqué « Code fourni — Ne pas modifier », sauf dans l’exercice 9 où la correction des bogues est le travail demandé.

Difficulté : ★☆☆ départ guidé; ★★☆ plusieurs conditions ou DOM; ★★★ activité plus autonome. Les étoiles servent à choisir un ordre de pratique, sans modifier les critères d’évaluation.

| Dossier | Objectif | Difficulté | Source exacte |
|---|---|---|---|
| exercice01 | Tester des valeurs et afficher un message. | ★☆☆ | `web/static/files/420905_lab5/lab5_exercice1/` |
| exercice02 | Choisir une réponse selon une valeur. | ★☆☆ | `web/static/files/420905_lab5/lab5_exercice2/` |
| exercice03 | Utiliser une condition pour vérifier une classe CSS. | ★★☆ | `web/static/files/rencontre9/conditions-dom/` |
| exercice04 | Choisir une image selon son texte alternatif. | ★★☆ | `web/static/files/rencontre9/conditions-dom/` |
| exercice05 | Faire alterner deux ampoules avec un bouton. | ★★☆ | `web/static/files/420905_lab5/lab5_exercice3/` |
| exercice06 | Adapter deux personnages selon la température. | ★★★ | `web/static/files/420905_lab5/lab5_exercice4/` |
| exercice07 | Afficher un résultat parmi plusieurs possibilités. | ★★☆ | `web/static/files/420905_lab6/lab6_exercice1/` |
| exercice08 | Comparer des prix avec des opérateurs logiques. | ★★☆ | `web/static/files/420905_lab6/lab6_exercice2/` |
| exercice09 | Repérer et corriger les erreurs volontaires. | ★★★ | `web/static/files/420905_lab6/lab6_exercice3/` |
| exercice10 | Gérer le papier, l’encre et les impressions. | ★★★ | `web/static/files/420905_lab6/lab6_exercice4/` |
