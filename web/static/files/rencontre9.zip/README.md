# Laboratoire de la rencontre 9 — Conditions et logique

Extrayez d’abord le ZIP. Ouvrez le dossier de chaque exercice, puis son fichier index.html dans un navigateur. Complétez les TODO dans js/script.js. Sauvegardez vos modifications, puis actualisez la page du navigateur avant de retester. Utilisez les boutons de test pour changer les valeurs des variables, puis les boutons d’action pour essayer votre code.

Conservez le code indiqué comme fourni. Les variables des exercices 05 et 10 doivent toutefois changer de valeur pendant l’exécution : conservez leurs déclarations et réaffectez leurs valeurs selon les consignes. Exception pour l’exercice 09 : corrigez les bogues intentionnels dans `init()` et les cinq fonctions `texteBleu()`, `texteRouge()`, `texteVert()`, `texteVariable()` et `bordureOuFond()`. Conservez ses variables globales ainsi que `changerCouleur()` et `changerStyle()`. Utilisez la console et corrigez une erreur à la fois.

Difficulté : ★☆☆ départ guidé; ★★☆ plusieurs conditions ou DOM; ★★★ activité plus autonome. Les étoiles servent à choisir un ordre de pratique, sans modifier les critères d’évaluation.

| Dossier | Objectif | Difficulté | Source exacte |
|---|---|---|---|
| exercice01 | Tester des valeurs et afficher un message. | ★☆☆ | `web/static/files/420905_lab5/lab5_exercice1/` |
| exercice02 | Choisir une réponse selon une valeur. | ★☆☆ | `web/static/files/420905_lab5/lab5_exercice2/` |
| exercice03 | Utiliser une condition pour vérifier une classe CSS. | ★★☆ | `web/static/files/rencontre9/conditions-dom/` |
| exercice04 | Choisir une image selon son texte alternatif. | ★★☆ | `web/static/files/rencontre9/conditions-dom/` |
| exercice05 | Faire alterner deux ampoules avec un bouton. | ★★☆ | `web/static/files/420905_lab5/lab5_exercice3/` |
| exercice06 | Adapter deux personnages selon la température. | ★★★ | `web/static/files/420905_lab5/lab5_exercice4/` |
| exercice07 | Afficher un résultat parmi plusieurs possibilités. | ★★☆ | `web/static/files/420905_lab6/lab6_exercice1/` |
| exercice08 | Comparer des prix avec des opérateurs logiques. | ★★☆ | `web/static/files/420905_lab6/lab6_exercice2/` |
| exercice09 | Repérer et corriger les erreurs volontaires. | ★★★ | `web/static/files/420905_lab6/lab6_exercice3/` |
| exercice10 | Gérer le papier, l’encre et les impressions. | ★★★ | `web/static/files/420905_lab6/lab6_exercice4/` |
