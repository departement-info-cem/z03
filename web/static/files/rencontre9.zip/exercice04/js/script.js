// Code à compléter : suivez tous les TODO ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : les écouteurs sont déjà en place.
function init(){
    document.querySelector(".bouton8").addEventListener("click", alternerImage);
}



// TODO 1 : Avec if/else, vérifiez la valeur de l'attribut alt de
// .objetBrun. Si elle vaut "Poop", donnez à src la valeur
// "images/chocolate.png" et à alt la valeur "Chocolat".
// Sinon, redonnez "images/poop.png" à src et "Poop" à alt.
function alternerImage(){

}
