// Code à compléter : suivez tous les TODO ci-dessous.
// Code fourni — Ne pas modifier : les parties déjà fonctionnelles servent à tester vos réponses.
// Code fourni — Ne pas modifier : variables globales
let gPrixPomme = 3;
let gPrixRaisin = 4;
let gPrixMelon = 5;
let gPortefeuille = 10;

// Code fourni — Ne pas modifier : les écouteurs d'événements sont déjà complétés !
function init(){

    document.querySelector(".bouton1").addEventListener("click", reduirePortefeuille);
    document.querySelector(".bouton2").addEventListener("click", augmenterPortefeuille);
    document.querySelector(".bouton3").addEventListener("click", reduirePrixPomme);
    document.querySelector(".bouton4").addEventListener("click", augmenterPrixPomme);
    document.querySelector(".bouton5").addEventListener("click", reduirePrixRaisin);
    document.querySelector(".bouton6").addEventListener("click", augmenterPrixRaisin);
    document.querySelector(".bouton7").addEventListener("click", reduirePrixMelon);
    document.querySelector(".bouton8").addEventListener("click", augmenterPrixMelon);

    document.querySelector(".bouton9").addEventListener("click", auMoinsUnPasCher);
    document.querySelector(".bouton10").addEventListener("click", tousChers);
    document.querySelector(".bouton11").addEventListener("click", tousMemePrix);
    document.querySelector(".bouton12").addEventListener("click", assezArgent);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter auMoinsUnPasCher()
//
// - Si au moins un des trois fruits coûte 3 ou moins, on remplace le texte 
//   de l'élément .texte par "Certains prix sont supers 🙏".
// - Comparez chaque prix à 3 avec <= et combinez avec OU (||).
// - Sinon, conservez le texte actuel.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function auMoinsUnPasCher(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter tousChers()
//
// - Vérifiez chaque prix avec > 5 et combinez avec ET (&&).
// - Si les trois fruits coûtent plus que 5, le texte est remplacé par 
//   "aaaaaaa les prix sont scandaleux ! 😠".
// - Sinon, le texte est remplacé par "Les prix sont pas pires 🤔".
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function tousChers(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 3 : Compléter tousMemePrix()
//
// - Si les trois fruits ont le même prix, le message affiché dans .texte
//   est "Huh pas très originaux ces prix 😨".
// - Sinon, ne changez pas le texte.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function tousMemePrix(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 4 : Compléter assezArgent()
//
// - Si j'ai assez d'argent dans mon portefeuille pour acheter 3 pommes, le
//   message dans .texte sera "Je suis un client très satisfait 🫃".
// - Sinon, si j'ai assez d'argent pour acheter 2 raisins OU 1 melon, le
//   message sera "Je suis un client un peu satisfait 🫃".
// - Sinon, le message sera "Je suis un client insatisfait 🦴".
// Utilisez >= : un montant exactement égal au coût suffit. Le choix de
// 3 pommes est prioritaire, même si les autres achats sont aussi possibles.
// Dans le deuxième choix, comparez séparément les coûts et combinez avec OU (||).
// C’est une simulation : ne consommez pas l’argent et ne modifiez pas les prix.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
function assezArgent(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// Code fourni — Ne pas modifier.
// Ne pas toucher le code à partir d'ici. Ce sont seulement les fonctions qui
// permettent de modifier les valeurs des variables globales en jouant avec
// les boutons dans la page.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function reduirePortefeuille(){

    gPortefeuille -= 1;
    document.querySelector(".portefeuille").textContent = gPortefeuille;
    document.querySelector(".texte").textContent = "⌛";

}

function augmenterPortefeuille(){

    gPortefeuille += 1;
    document.querySelector(".portefeuille").textContent = gPortefeuille;
    document.querySelector(".texte").textContent = "⌛";

}

function reduirePrixPomme(){

    gPrixPomme -= 1;
    document.querySelector(".prixPomme").textContent = gPrixPomme;
    document.querySelector(".texte").textContent = "⌛";

}

function augmenterPrixPomme(){

    gPrixPomme += 1;
    document.querySelector(".prixPomme").textContent = gPrixPomme;
    document.querySelector(".texte").textContent = "⌛";

}

function reduirePrixRaisin(){

    gPrixRaisin -= 1;
    document.querySelector(".prixRaisin").textContent = gPrixRaisin;
    document.querySelector(".texte").textContent = "⌛";

}

function augmenterPrixRaisin(){

    gPrixRaisin += 1;
    document.querySelector(".prixRaisin").textContent = gPrixRaisin;
    document.querySelector(".texte").textContent = "⌛";

}

function reduirePrixMelon(){

    gPrixMelon -= 1;
    document.querySelector(".prixMelon").textContent = gPrixMelon;
    document.querySelector(".texte").textContent = "⌛";

}

function augmenterPrixMelon(){

    gPrixMelon += 1;
    document.querySelector(".prixMelon").textContent = gPrixMelon;
    document.querySelector(".texte").textContent = "⌛";

}
// Les opérateurs +=/-= présents dans le code fourni servent uniquement aux boutons de test; leur fonctionnement n’est pas à apprendre pour cet exercice.
