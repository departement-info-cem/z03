// Code à compléter : suivez tous les TODO ci-dessous.
// Le HTML et le CSS sont fournis; créez le code JavaScript demandé.
// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Tout coder
//
// Déclarez une variable globale initialisée à 20 pour conserver la température.
//
// - Rendre les boutons 🔽🔼 fonctionnels : ils permettent de réduire et
//   d’augmenter la température de 1 °C par clic. Dans init(), reliez
//   .down et .up aux fonctions que vous créez. À chaque clic, mettez à jour
//   .temperature (nombre suivi de " °C") et les deux opacités.
//
// - Changer l'opacité du Ice Bro et du Fire Bro au besoin ... :
//     🧊 L'opacité du Ice Bro est de 1 si la température est sous 15 et
//        elle (l'opacité) est de 0.2 sinon.
//     🔥 L'opacité du Fire Bro est de 1 si la température est au-dessus de
//        10 et elle (l'opacité) est de 0.2 sinon.
//
// Utilisez style.opacity sur .iceBro et .fireBro, avec deux décisions distinctes.
// Tests : 10 °C → Ice 1, Fire 0.2; 12 °C → les deux 1;
//         15 °C → Ice 0.2, Fire 1. De 11 à 14 °C, les deux sont opaques.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Code à compléter : variable(s) globale(s)



// Code à compléter : écouteur(s) d'événements
function init(){



}

// Vos fonctions


