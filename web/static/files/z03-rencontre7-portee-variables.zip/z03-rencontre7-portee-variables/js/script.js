// RAPPEL : Quand on vous demande de faire quelque chose « dans la console »,
//          ouvrez la page HTML de ce projet dans Chrome ou Firefox, puis ouvrez
//          la console avec F12 / Inspecter.

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 :
// - Déclarez une variable globale nommée gNombre ci-dessous, dans le code, et
//   affectez-lui la valeur 3.
// - Ensuite, dans la console du navigateur, faites 2 choses :
//      - Écrivez le nom gNombre pour vérifier que la variable existe bien.
//      - Toujours dans la console, faites gNombre += 1 pour vérifier que sa valeur
//        devient 4.
//
// Si les deux dernières étapes ont bien fonctionné, vous avez créé une variable
// GLOBALE avec succès ! Vous pouvez passer au TODO 2.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ↓ Déclarer gNombre ici ! ↓




// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 :
// - Déclarez une variable locale nommée « nombre » et affectez-lui la valeur 6
//   à l'intérieur de la fonction nombreConsole() ci-dessous.
// - Dans la console du navigateur, tentez ensuite d'utiliser la variable nombre.
//   Ce n'est pas censé fonctionner, car la variable est locale à nombreConsole().
//
// Si la console n'est pas capable de vous donner la valeur de la variable nombre,
// c'est que vous avez bien réussi à créer une variable LOCALE.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function nombreConsole(){

    // ↓ Déclarer nombre ici ! ↓



    console.log(nombre);

}

/* EN RÉSUMÉ :
- gNombre est une variable globale. On peut modifier sa valeur et l'utiliser
  dans la console et dans plusieurs fonctions.
- nombre est une variable locale. On peut l'utiliser dans nombreConsole(),
  mais pas à l'extérieur de cette fonction.
*/
