# Rencontre 12 — Tableaux et parcours

Ce dossier contient les deux exercices **essentiels**.

- **exercice01** : accéder aux données, modifier un élément, ajouter (`push`), retirer (`pop`) et supprimer plusieurs données (`splice`).
- **exercice02** : parcourir un tableau avec `while`, calculer une somme et modifier toutes les valeurs.

Décompressez le ZIP, ouvrez `index.html` dans le navigateur et complétez les TODO dans `js/script.js`. Les boutons et leurs écouteurs d'événements sont déjà fournis. Rafraîchissez la page entre les tests lorsque les tableaux sont modifiés.

Pour les défis facultatifs, téléchargez séparément `rencontre12-pour-aller-plus-loin.zip` sur la page de laboratoire.