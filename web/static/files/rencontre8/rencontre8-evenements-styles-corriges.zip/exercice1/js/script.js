let gNouveauTexte = "La hippopotomonstrosesquippedaliophobie est la phobie des longs mots. 😨";
let gTexteAlerte = "COMMENT OSEZ-VOUS SURVOLER CE BOUTON ? 😡";

function init() {
    document.querySelector(".bouton1").addEventListener("click", changerTexte);
    document.querySelector(".bouton2").addEventListener("mouseover", lancerAlerte);
    document.querySelector(".bouton3").addEventListener("mouseout", imprimerDansConsole);
}

function changerTexte() {
    document.querySelector(".texte").textContent = gNouveauTexte;
}

function lancerAlerte() {
    alert(gTexteAlerte);
}

function imprimerDansConsole() {
    console.log("Tu as arrêté de survoler le 3e bouton 😠 !");
}
