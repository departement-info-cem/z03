// Ce projet n'a aucune variable globale

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Regarder la fonction init()
// - Il n'y a rien à ajouter dans la fonction init(). Un écouteur d'événements
//   de type "click" est déjà créé pour tous les boutons.
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function init(){

    document.querySelector(".bouton1").addEventListener("click", couleurTexte);
    document.querySelector(".bouton2").addEventListener("click", couleurFond);
    document.querySelector(".bouton3").addEventListener("click", couleurBordure);
    document.querySelector(".bouton4").addEventListener("click", largeurBordure);
    document.querySelector(".bouton5").addEventListener("click", tailleBouton);
    document.querySelector(".bouton6").addEventListener("click", opaciteBouton);
    document.querySelector(".bouton7").addEventListener("click", visibiliteBouton);

}


function couleurTexte() {
    document.querySelector(".bouton1").style.color = "red";
}

function couleurFond() {
    document.querySelector(".bouton2").style.backgroundColor = "gold";
}

function couleurBordure() {
    document.querySelector(".bouton3").style.borderColor = "blue";
}

function largeurBordure() {
    document.querySelector(".bouton4").style.borderWidth = "10px";
}

function tailleBouton() {
    document.querySelector(".bouton5").style.width = "300px";
    document.querySelector(".bouton5").style.height = "100px";
}

function opaciteBouton() {
    document.querySelector(".bouton6").style.opacity = 0.2;
}

function visibiliteBouton() {
    document.querySelector(".bouton7").style.display = "none";
}
