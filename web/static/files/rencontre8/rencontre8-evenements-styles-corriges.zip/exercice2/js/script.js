let gCompteur = 0;

function init() {
    document.querySelector(".up").addEventListener("click", augmenterCompteur);
    document.querySelector(".down").addEventListener("click", reduireCompteur);
}

function augmenterCompteur() {
    gCompteur = gCompteur + 1;
    document.querySelector(".compteur").textContent = gCompteur;
}

function reduireCompteur() {
    gCompteur = gCompteur - 1;
    document.querySelector(".compteur").textContent = gCompteur;
}
