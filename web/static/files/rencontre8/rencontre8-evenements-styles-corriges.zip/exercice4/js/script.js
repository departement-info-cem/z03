function init() {
    document.querySelector(".lightOff").addEventListener("mouseover", on);
    document.querySelector(".lightOn").addEventListener("mouseout", off);
}

function on() {
    document.querySelector(".lightOff").style.display = "none";
    document.querySelector(".lightOn").style.display = "block";
}

function off() {
    document.querySelector(".lightOn").style.display = "none";
    document.querySelector(".lightOff").style.display = "block";
}
