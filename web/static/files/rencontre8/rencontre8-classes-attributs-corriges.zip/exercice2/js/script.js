// Écouteurs d'événements (rien à ajouter)
function init(){

    document.querySelector(".sobre").addEventListener("click", styleSobre);
    document.querySelector(".flashy").addEventListener("click", styleFlashy);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Modifier styleFlashy() et styleSobre()
//
// - Pour le moment, le code « imageMario » est répété
//   cinq fois dans chacune de ces deux fonctions. Rangez l'élément .image dans
//   une variable pour remplacer le code répétitif.
//
// - Pour ces deux fonctions, n'hésitez jamais à faire cela DÈS qu'un
//   élément HTML est manipulé plus d'une fois ! 📈🏆
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function styleFlashy(){
    let imageMario = document.querySelector(".image");

    imageMario.classList.add("flashy");
    imageMario.classList.remove("sobre");
    imageMario.title = "Mario flashy 🌈";
    imageMario.src = "images/flashy.png";
    imageMario.alt = "Mario flashy";

}

function styleSobre(){
    let imageMario = document.querySelector(".image");

    imageMario.classList.remove("flashy");
    imageMario.classList.add("sobre");
    imageMario.title = "Mario sobre 🤵";
    imageMario.src = "images/sobre.png";
    imageMario.alt = "Mario sobre";

}


