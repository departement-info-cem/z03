
// Écouteurs d'événements (Rien à ajouter)
function init(){

    document.querySelector(".bouton1").addEventListener("click", ajouterClasse);
    document.querySelector(".bouton2").addEventListener("click", retirerClasse);
    document.querySelector(".bouton3").addEventListener("click", basculerClasse);

    document.querySelector(".bouton4").addEventListener("click", ajouterAttribut);
    document.querySelector(".bouton5").addEventListener("click", retirerAttribut);
    document.querySelector(".bouton6").addEventListener("click", modifierAttribut);

}


function ajouterClasse() {
    document.querySelector(".texte1").classList.add("brun");
}

function retirerClasse() {
    document.querySelector(".texte1").classList.remove("brun");
}

function basculerClasse() {
    document.querySelector(".texte1").classList.toggle("brun");
}

function ajouterAttribut() {
    document.querySelector(".objetBrun").title = "Trop mignon ! 💩";
}

function retirerAttribut() {
    document.querySelector(".objetBrun").title = "";
}

function modifierAttribut() {
    document.querySelector(".objetBrun").src = "images/chocolate.png";
    document.querySelector(".objetBrun").alt = "Morceau de chocolat";
}
