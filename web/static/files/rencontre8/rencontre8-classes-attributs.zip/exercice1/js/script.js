
// Écouteurs d'événements (Rien à ajouter)
function init(){

    document.querySelector(".bouton1").addEventListener("click", ajouterClasse);
    document.querySelector(".bouton2").addEventListener("click", retirerClasse);
    document.querySelector(".bouton3").addEventListener("click", basculerClasse);

    document.querySelector(".bouton4").addEventListener("click", ajouterAttribut);
    document.querySelector(".bouton5").addEventListener("click", retirerAttribut);
    document.querySelector(".bouton6").addEventListener("click", modifierAttribut);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter les fonctions ajouterClasse(), retirerClasse()
//          et basculerClasse().
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// ajouterClasse() ajoute la classe "brun" à l'élément .texte1
function ajouterClasse(){



}

// retirerClasse() retire la classe "brun" à l'élément .texte1
function retirerClasse(){



}

// basculerClasse() bascule la présence de la classe "brun" à l'élément .texte1
// Donc si on spam le bouton... la classe va alterner entre présente et absente.
function basculerClasse(){



}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 2 : Compléter les fonctions ajouterAttribut(), retirerAttribut()
//          et modifierAttribut().
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

// Ajoutez l'attribut title avec la valeur "Trop mignon ! 💩" pour l'élément .objetBrun
// Pour vérifier que ça marche, survolez l'image et immobilisez la souris.
function ajouterAttribut(){



}

// Videz / retirez l'attribut title pour l'élément .objetBrun
function retirerAttribut(){



}

// Pour l'élément .objetBrun, changez la valeur de l'attribut src par "images/chocolate.png"
// et celle de l'attibut alt par "Un morceau de chocolat".
function modifierAttribut(){



}

