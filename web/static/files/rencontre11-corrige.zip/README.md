# Rencontre 11 — Corrigés des exercices sur les boucles

Cette archive est distincte de l'archive des exercices étudiants.

Les dossiers `exercice01`, `exercice02` et `exercice03` présentent des solutions possibles. Ouvrez le fichier `js/script.js` de chaque dossier pour comparer les fonctions, après avoir tenté l'exercice. Les pages `index.html` permettent de tester les boutons.

Les exercices 1 et 2 sont essentiels. L'exercice 3 est un défi facultatif.
