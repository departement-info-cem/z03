// Écouteur d'événements (Déjà créé)
function init(){

    document.querySelector(".bouton").addEventListener("click", calculer);

}

// ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
// TODO 1 : Compléter la fonction calculer().
//
// - À l'aide d'une boucle, calculez le prix total des aliments, sachant que :
//
// -> 2$ par 🍊
// -> 1$ par 🍋
// -> Les fruits avec un fond limegreen sont à moitié prix.
//
// Affichez le prix total dans une alerte avec le symbole $ après. (Si vous avez
// bien fait le code, ça devrait être "33 $")
//
// Astuce : on peut vérifier un style en faisant ceci :
//          document.querySelector(...).style.propriété == "valeur"
// ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀

function calculer(){

    let prixTotal = 0;
    let i = 1;
    while(i <= 25){
        let fruit = document.querySelector(".fruit" + i);
        let prix = 0;
        if(fruit.textContent == "🍋"){
            prix = 1;
        }else if(fruit.textContent == "🍊"){
            prix = 2;
        }
        if(fruit.style.backgroundColor == "limegreen"){
            prix = prix / 2;
        }
        prixTotal += prix;
        i += 1;
    }
    alert(prixTotal + " $");

}