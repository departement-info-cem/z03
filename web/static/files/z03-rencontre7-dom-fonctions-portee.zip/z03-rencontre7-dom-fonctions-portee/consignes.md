# Rencontre 7 — DOM, fonctions et portée des variables

Ce laboratoire contient quatre exercices. Ouvrez chaque dossier dans VS Code et testez le fichier `index.html` dans Chrome ou Firefox.

## Exercice 1 — DOM dans la console

Dossier : `exercice1-dom`

1. Avec `document.querySelector(...)` et `.textContent`, lisez le texte de `.titre1`.
2. Remplacez le texte de `.texteMC` par `Non, c'est un cochon.`.
3. Trouvez dans le HTML la classe du titre **Bokoblin**, puis remplacez son texte par `Goomba`.
4. Récupérez le texte de `.titre3` dans une variable nommée `titre`, puis affectez cette valeur au `.textContent` de `.textePeppa`.
5. Actualisez la page, puis ajoutez à la fin de `.textePeppa` l'un des textes suivants : ` Yikes.`, ` Cringe.` ou ` Ouash.`, avec `+=`.
6. Actualisez encore la page, puis ajoutez `Peppa pig` au début du texte existant du paragraphe.

## Exercice 2 — Lire et appeler des fonctions

Dossier : `exercice2-fonctions-mystere`

Ouvrez `index.html` et `js/script.js`. Lisez les fonctions `mystere1()` à `mystere5()`, puis appelez dans la console la fonction qui :

1. remplace `Pomme 🍎` par `Poire 🍐`;
2. affiche `Poire 🍐` dans la console;
3. ajoute `Raisin 🍇` après `Pêche 🍑`.

## Exercice 3 — Créer vos propres fonctions

Dossier : `exercice3-creer-fonctions`

Complétez `js/script.js`. Les TODO dans le fichier décrivent les six fonctions à créer. Après chaque fonction, enregistrez, actualisez la page et appelez la fonction dans la console.

## Exercice 4 — Portée des variables

Dossier : `exercice4-portee-variables`

Suivez les TODO dans `js/script.js`.

Vous créerez :
- une variable globale `gNombre` à l'extérieur d'une fonction;
- une variable locale `nombre` à l'intérieur de `nombreConsole()`.

Testez ensuite dans la console quelles variables sont accessibles et lesquelles ne le sont pas.
