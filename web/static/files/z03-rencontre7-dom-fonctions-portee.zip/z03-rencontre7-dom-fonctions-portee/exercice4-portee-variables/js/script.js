// RAPPEL : Quand on vous demande de faire quelque chose « dans la console »,
// ouvrez la page HTML dans votre navigateur, puis ouvrez la console avec F12 / Inspecter.

// TODO 1 :
// - Déclarez une variable globale nommée gNombre ci-dessous et affectez-lui la valeur 3.
// - Dans la console du navigateur, écrivez gNombre pour vérifier sa valeur.
// - Toujours dans la console, faites gNombre += 1 pour vérifier que la valeur devient 4.

// ↓ Déclarer gNombre ici ! ↓




// TODO 2 :
// - Déclarez une variable locale nommée nombre et affectez-lui la valeur 6
//   à l'intérieur de la fonction nombreConsole().
// - Appelez nombreConsole() pour vérifier que la fonction peut utiliser la variable.
// - Dans la console, tentez ensuite d'écrire seulement nombre.
//   Cela ne devrait pas fonctionner, car nombre est locale à la fonction.

function nombreConsole(){

    // ↓ Déclarer nombre ici ! ↓
    
    
    
    console.log(nombre);

}

/* EN RÉSUMÉ :
- gNombre est une variable globale. Elle peut être utilisée dans plusieurs fonctions et dans la console.
- nombre est une variable locale. Elle existe seulement dans nombreConsole().
*/