// Il n'y a rien à modifier dans ce fichier pour l'exercice 1.
// Le JavaScript de cet exercice est écrit directement dans la console du navigateur.
