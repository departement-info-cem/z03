// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•
// Exercice 3 - Créez vos propres fonctions !
// •○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•○•

// ⭐ N'OUBLIEZ PAS qu'une fonction possède la structure suivante :
// • Le mot-clé function
// • Un nom pour identifier la fonction
// • Des parenthèses vides () après le nom
// • Une accolade ouvrante { pour indiquer où la fonction commence
// • Une accolade fermante } pour indiquer où la fonction termine

// 🤓 Après avoir codé une fonction, allez la tester dans la console de la page Web !

// TODO 1 : Fonction nommée quatreEtCinq() qui remplace le texte des éléments avec les classes
// .quatre et .cinq par "Zombies 🧟‍♂️" et "Vampires 🧛‍♂️", respectivement.

// ↓ ÉCRIRE LA FONCTION quatreEtCinq() ICI ! ↓




// TODO 2 : Fonction nommée byeLicornes() qui remplace le contenu textuel de .trois par ""
// et génère une alerte avec le texte "Bye 😭".

// ↓ ÉCRIRE LA FONCTION byeLicornes() ICI ! ↓




// TODO 3 : Fonction nommée test() qui affiche le texte "Test réussi !" dans la console.

// ↓ ÉCRIRE LA FONCTION test() ICI ! ↓




// TODO 4 : Fonction nommée texteDeux() qui concatène " et génies 🧞" à l'élément .deux.

// ↓ ÉCRIRE LA FONCTION texteDeux() ICI ! ↓




// TODO 5 : Fonction nommée dragonDansConsole() qui récupère le contenu textuel de .un,
// puis qui affiche ce texte dans la console.

// ↓ ÉCRIRE LA FONCTION dragonDansConsole() ICI ! ↓




// TODO 6 : Fonction nommée alerteLicorneMage() qui récupère le contenu textuel de .trois,
// concatène " et mages 🧙‍♂️" à la fin de ce texte, puis affiche tout dans une alerte.

// ↓ ÉCRIRE LA FONCTION alerteLicorneMage() ICI ! ↓


