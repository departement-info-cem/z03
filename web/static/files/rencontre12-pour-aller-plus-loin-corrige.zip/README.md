# Rencontre 12 — Corrigés pour aller plus loin

Ce ZIP contient les solutions des quatre activités facultatives. Les exercices essentiels et leurs corrigés se trouvent dans d'autres archives. Les solutions sont séparées des fichiers de départ.
