// Rencontre 12 — Exercice 1 : premières opérations sur les tableaux
// Rafraîchissez la page entre deux tests afin de repartir des tableaux de départ.

let gNbEntiers = [5, 2, 9, 1, 4, 7];
let gCouleurs = ["bleu", "rouge", "jaune", "vert"];
let gBooleens = [true, false, false, true, true];
let gNbDecimaux = [4.44, 3.33, 1.11, 5.55, 2.22];

// Écouteurs d'événements déjà fournis : ne pas modifier.
function init(){
    document.querySelector(".bouton1").addEventListener("click", alerte1);
    document.querySelector(".bouton2").addEventListener("click", alerte2);
    document.querySelector(".bouton3").addEventListener("click", modification1);
    document.querySelector(".bouton5").addEventListener("click", ajout1);
    document.querySelector(".bouton7").addEventListener("click", retrait1);
    document.querySelector(".bouton9").addEventListener("click", epissure1);
}

// TODO 1 : afficher la première donnée de gCouleurs dans une alerte.
function alerte1(){
    alert("La première donnée dans gCouleurs est : " + gCouleurs[0]);
}

// TODO 2 : afficher la dernière donnée de gNbEntiers en utilisant length.
function alerte2(){
    alert("La dernière donnée dans gNbEntiers est : " + gNbEntiers[gNbEntiers.length - 1]);
}

// TODO 3 : remplacer 1.11 par 7.77 dans gNbDecimaux et actualiser .tableau4.
function modification1(){
    gNbDecimaux[2] = 7.77;
    document.querySelector(".tableau4").textContent = gNbDecimaux;
}

// TODO 4 : ajouter 8 à la fin de gNbEntiers (push) et actualiser .tableau1.
function ajout1(){
    gNbEntiers.push(8);
    document.querySelector(".tableau1").textContent = gNbEntiers;
}

// TODO 5 : retirer la dernière valeur de gNbDecimaux (pop) et actualiser .tableau4.
function retrait1(){
    gNbDecimaux.pop();
    document.querySelector(".tableau4").textContent = gNbDecimaux;
}

// TODO 6 : retirer les trois premières données de gNbEntiers (splice) et actualiser .tableau1.
function epissure1(){
    gNbEntiers.splice(0, 3);
    document.querySelector(".tableau1").textContent = gNbEntiers;
}
