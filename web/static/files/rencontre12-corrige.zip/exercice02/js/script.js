// Rencontre 12 — Exercice 2 : parcourir un tableau
// Rafraîchissez la page entre les tests si vous avez modifié les prix.

let gFruits = ["🍓", "🍋", "🍏", "🍇", "🍊"];
let gPrix = [4.99, 1.95, 2.49, 6.45, 1.45];
let gJoueurs = ["crewmate", "crewmate", "impostor", "impostor", "crewmate", "impostor"];

// Écouteurs d'événements déjà fournis : ne pas modifier.
function init(){
    document.querySelector(".bouton1").addEventListener("click", fruitsConsole);
    document.querySelector(".bouton2").addEventListener("click", totalPrix);
    document.querySelector(".bouton4").addEventListener("click", inflationSoudaine);
}

// TODO 1 : parcourir gFruits avec while et afficher chaque fruit dans la console.
function fruitsConsole(){
    let i = 0;
    while(i < gFruits.length){
        console.log(gFruits[i]);
        i += 1;
    }
}

// TODO 2 : calculer la somme de gPrix avec while et afficher le total dans la console (17.33).
function totalPrix(){
    let total = 0;
    let i = 0;
    while(i < gPrix.length){
        total += gPrix[i];
        i += 1;
    }
    console.log("Le prix total est " + total + " dollars");
}

// TODO 3 : augmenter chaque prix de 1 avec while, puis afficher le tableau actualisé dans la console.
function inflationSoudaine(){
    let i = 0;
    while(i < gPrix.length){
        gPrix[i] += 1;
        i += 1;
    }
    console.log(gPrix);
}
