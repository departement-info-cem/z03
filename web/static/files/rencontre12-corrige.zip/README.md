# Rencontre 12 — Corrigés essentiels

Ce ZIP contient uniquement les corrigés des deux exercices essentiels.

Ouvrez les dossiers séparément et consultez leurs `js/script.js`. Les solutions sont des exemples possibles. N'intégrez pas ce ZIP dans votre dossier de départ étudiant.