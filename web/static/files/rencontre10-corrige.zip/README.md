# Rencontre 10 — Corrigés : fonctions avec paramètres et retours

Cette archive contient les corrigés des exercices **1 et 2 seulement**.

Pour comparer votre solution, ouvrez le `index.html` dans chaque dossier (`exercice01` et `exercice02`) et consultez `js/script.js`.

Les corrigés sont volontairement **séparés** des exercices destinés aux étudiants.

Ce sont des solutions possibles : d'autres versions fonctionnelles peuvent être valides.
