// 🎮 TP2 — Roche-Papier-Ciseaux
//
// TON PARCOURS : cherche « MISSION 1 », puis « MISSION 2 », etc. (Ctrl+F).
// 🎯 MISSION 1 (R7) : afficher les scores.
// 🎨 MISSION 2 (R8) : mettre les images en gris.
// 🏆 MISSION 3 (R9) : déterminer qui gagne chaque confrontation.
// 🥇 MISSION 4 (R9) : annoncer le gagnant après 10 confrontations.
// 🔄 MISSION 5 (R10) : préparer la prochaine partie.
//
// ✏️ Écris uniquement dans les zones « À TOI ».
// Pour les consignes et les indices : ouvre ENONCE_TP2.html.

// Ces nombres représentent les choix : 0 = Roche, 1 = Ciseaux, 2 = Papier.
// Ils permettent de comparer les choix des joueurs.
// « const » = valeur qu'on ne réaffecte pas (explication dans l'énoncé).
const ROCHE = 0;
const CISEAUX = 1;
const PAPIER = 2;
const NB_CONFRONTATIONS_MAX = 10;

// Code fourni : hasard et images (aucun tableau à programmer).
const choixImages = ['roche', 'ciseaux', 'papier'];

// Les compteurs peuvent changer : on utilise « let ».
let nbConfrontations = 0;
let confrontationsNulles = 0;
let victoiresJoueur1 = 0;
let victoiresJoueur2 = 0;
let partiesGagneesJoueur1 = 0;
let partiesGagneesJoueur2 = 0;

// ── 🎯 MISSION 1 (R7) : le tableau de bord ────────────────────
function afficherResultat() {
  // ✅ Exemple fourni : afficher le nombre de confrontations.
  document.querySelector('#idNbConfs').textContent = nbConfrontations;

  // ✏️ À TOI : affiche les 5 autres compteurs de la même façon.
  // Cherche leurs « id » dans index.html.
  // 🧪 Test : « Tester les compteurs (R7) » dans le jeu.
  // TON CODE ICI — MISSION 1
}

// ── 🎨 MISSION 2 (R8) : les couleurs au neutre ───────────────
function preparerImages() {
  // ✏️ À TOI : pour CHACUNE des deux images :
  // 1. retire les classes « rouge » et « vert » avec classList.remove().
  // 2. ajoute la classe « gris » avec classList.add().
  // 🧩 Exemple : document.querySelector('#idPhotoJ1').classList.remove('rouge');
  // 🧪 Test : « Tester les bordures (R8) » dans le jeu.
  // TON CODE ICI — MISSION 2
}

// ── 🏆 MISSION 3 ET 🥇 MISSION 4 : les règles du jeu ────────
function jouer() {
  // 🥇 MISSION 4A (R9) — Le clic APRÈS la 10e confrontation.
  // ✏️ Remplace « false » par : nbConfrontations == NB_CONFRONTATIONS_MAX
  // ✏️ Dans le if, appelle nouvellePartie().
  if (false) {
    // TON CODE ICI — MISSION 4A : appeler nouvellePartie()
    return; // ✅ Fourni : arrête cette fonction (aucune nouvelle confrontation).
  }

  // ✅ Fourni : tirer et afficher les choix des joueurs.
  const choixJoueur1 = Math.floor(Math.random() * 3);
  const choixJoueur2 = Math.floor(Math.random() * 3);
  document.querySelector('#idPhotoJ1').src =
    'images/' + choixImages[choixJoueur1] + '.png';
  document.querySelector('#idPhotoJ2').src =
    'images/' + choixImages[choixJoueur2] + '.png';
  nbConfrontations += 1;

  // 🎨 MISSION 2 (R8) — ✏️ Appelle ici preparerImages().
  // TON CODE ICI — APPEL MISSION 2

  // 🏆 MISSION 3 (R9) — Qui gagne cette confrontation?
  // Étape 3.1 — ✅ Le premier if est donné.
  if (choixJoueur1 == choixJoueur2) {
    // ✏️ Égalité : +1 à confrontationsNulles; les 2 images restent grises.
    // La fonction preparerImages() s'est déjà occupée du gris.
    // TON CODE ICI — 3.1
  }
  // Étape 3.2 — ✏️ Juste après ce « } », écris « else if (...) ».
  // Roche bat Ciseaux OU Ciseaux battent Papier OU Papier bat Roche.
  // Utilise && pour un duo et || entre les trois duos.
  // Construis la condition avec choixJoueur1 et choixJoueur2
  // (leurs choix pour ce duel) et ROCHE, PAPIER, CISEAUX.
  // Puis : +1 à victoiresJoueur1; enlève « gris » des deux images,
  // donne la classe « vert » à J1 et « rouge » à J2.
  //
  // Étape 3.3 — ✏️ Dans tous les autres cas :
  // +1 à victoiresJoueur2; enlève « gris » des deux images,
  // donne la classe « rouge » à J1 et « vert » à J2.
  //
  // ⚠️ Le if, le else if et le else forment UN SEUL ensemble.
  // TON CODE ICI — 3.2 ET 3.3

  // ✅ Fourni : numéro de la confrontation en cours.
  document.querySelector('#idMessage').textContent =
    'Confrontation ' + nbConfrontations + ' sur ' + NB_CONFRONTATIONS_MAX;

  // 🥇 MISSION 4B (R9) — Qui remporte la partie après 10 coups?
  // ✏️ 1. Avec un if, vérifie si on est à la 10e confrontation.
  // ✏️ 2. À l'intérieur, compare les scores avec if / else if / else :
  //          J1 > J2  →  J1 gagne; J2 > J1  →  J2 gagne; sinon : nulle.
  // ✏️ 3. Augmente le bon compteur des PARTIES gagnées (sauf si nulle).
  // ✏️ 4. Écris dans #idMessageFin le message exact selon le cas :
  // « Le joueur 1 remporte la partie! »
  // « Le joueur 2 remporte la partie! »
  // « La partie se termine par une égalité! »
  // ✏️ 5. Change #idBtnJouer en « Nouvelle partie ».
  // 💡 Un exemple plus détaillé est disponible dans l'énoncé.
  // TON CODE ICI — MISSION 4B

  // ✅ Fourni : mettre à jour les scores APRÈS le calcul final.
  afficherResultat();
}

// ── 🔄 MISSION 5 (R10) : on recommence! ───────────────────────
function nouvellePartie() {
  // ✏️ À TOI : remets à zéro ces 4 compteurs :
  // nbConfrontations, confrontationsNulles, victoiresJoueur1, victoiresJoueur2.
  // ❗ Garde les partiesGagneesJoueur1 et partiesGagneesJoueur2.
  // ✏️ Efface #idMessageFin avec textContent = ''.
  // ✏️ Appelle afficherResultat(), puis preparerImages().
  // TON CODE ICI — MISSION 5

  // ✅ Fourni : retrouver l'apparence de départ (ne pas modifier).
  document.querySelector('#idPhotoJ1').src = 'images/roche.png';
  document.querySelector('#idPhotoJ2').src = 'images/roche.png';
  document.querySelector('#idBtnJouer').textContent = 'JOUER !';
  document.querySelector('#idMessage').textContent =
    'Nouvelle partie : à vous de jouer!';
}

// ✅ Fourni : le bouton JOUER déclenche la fonction jouer().
document.querySelector('#idBtnJouer').addEventListener('click', jouer);
