// TP3 — Le coffre des mots
// Garde ton travail de R11 quand tu passes à R12, puis à R13.
// Déclare tes variables globales ici avec le préfixe g (ex. gErreurs). Écris tes fonctions dans ce fichier.

function init() {
  // R11 : associe le bouton #jeuBouton à testerErreur(), puis appelle afficherTorches().
  // En R13, tu remplaceras testerErreur par essayerLettre et ajouteras afficherMot().
}

// Écris tes fonctions du jeu ici, au-dessus de l'outil fourni.


// OUTIL FOURNI — Ne pas modifier.
// Retourne une lettre majuscule (A à Z) ou "" si la saisie n'est pas valide.
function lireLettre() {
  let champ = document.querySelector("#lettre");
  let resultat = champ.value.trim().toUpperCase();
  champ.value = "";
  if (!/^[A-Z]$/.test(resultat)) {
    return "";
  }
  return resultat;
}
