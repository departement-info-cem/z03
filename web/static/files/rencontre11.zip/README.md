# Rencontre 11 — Boucles `while`

Cette archive contient les trois activités de pratique de R11.

## Démarrage

1. Enregistrez et décompressez le ZIP avant de commencer.
2. Ouvrez le dossier `exercice01`, puis `index.html` dans un navigateur.
3. Complétez les fonctions demandées dans `js/script.js` avec Visual Studio Code.
4. Testez vos réponses en cliquant sur les boutons dans la page.
5. Passez ensuite à `exercice02`, puis à `exercice03` si le temps le permet.

**Exercices 1 et 2 :** pratique essentielle des boucles `while` et des conditions.
**Exercice 3 :** défi d'intégration facultatif (boucles, conditions, DOM).

Les événements sont déjà branchés dans le code fourni. Vous n'avez pas à modifier les fonctions `init()`.
