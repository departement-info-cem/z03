// Rencontre 12 : exercices facultatifs autonomes.
// Ce fichier n'inclut aucune solution aux exercices essentiels.
// Rafraîchissez la page entre les tests si vous modifiez les tableaux.

let gNbEntiers = [5, 2, 9, 1, 4, 7];
let gCouleurs = ["bleu", "rouge", "jaune", "vert"];
let gBooleens = [true, false, false, true, true];
let gNbDecimaux = [4.44, 3.33, 1.11, 5.55, 2.22];

// Écouteurs fournis : ne pas modifier.
function init(){
    document.querySelector(".bouton4").addEventListener("click", modification2);
    document.querySelector(".bouton6").addEventListener("click", ajout2);
    document.querySelector(".bouton8").addEventListener("click", retrait2);
    document.querySelector(".bouton10").addEventListener("click", epissure2);
}

// TODO 1 : dans gBooleens, remplacer le premier true par false et actualiser .tableau3.
function modification2(){
    // TODO : compléter.
}

// TODO 2 : ajouter cramoisi à gCouleurs et actualiser .tableau2.
function ajout2(){
    // TODO : compléter.
}

// TODO 3 : retirer le dernier booléen avec pop() et actualiser .tableau3.
function retrait2(){
    // TODO : compléter.
}

// TODO 4 : retirer la première couleur avec splice() et actualiser .tableau2.
function epissure2(){
    // TODO : compléter.
}
