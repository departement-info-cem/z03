# Rencontre 12 — Pour aller plus loin (FACULTATIF)

Ces activités sont facultatives et ne sont pas exigées à R12.

- complement-exercice01 : quatre autres opérations sur les tableaux; projet autonome, sans les réponses de l'exercice essentiel 1
- complement-exercice02 : budget d'achats et comptage de personnages; projet autonome, sans les réponses de l'exercice essentiel 2
- exercice03-amis : gérer une liste d'amis et actualiser l'interface
- exercice04-cochons : additionner des prix et comparer les valeurs d'un tableau

Ouvrez le fichier index.html de chaque dossier après décompression, puis complétez les TODO dans js/script.js. Les corrigés sont dans une autre archive.
